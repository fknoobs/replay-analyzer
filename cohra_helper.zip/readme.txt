
COHRA HELPER
============================================================================================
Sander Dijkstra, may 2009
www.dyxtra.com


This tool was made for my own personal use while developing COH Replay Analyzer to help me
easily find player commands and IDs inside Company of Heroes replay files.

I've made it publicly available to assist others making ID lists for COH Replay Analyzer,
or for those who just want to learn more about the Company of Heroes replay structure.

As a result of it being for internal use only, it is not very user friendly but it gets the
job done.


USAGE
============================================================================================
Open a replay by right-clicking on it, choosing 'Open with' and then pointing to COHRA Helper,
or by dragging a replay file onto the COHRA Helper executable.

The E8 through EF buttons parse the replay for that player ID*. Defaults to E8, which in a
fixed position game is the #1 allied player. Make sure you are checking the correct player ID
in random position games.

* Actual player IDs are 0x3e8-0x3ef (1000-1007). 



